# $ConfigData = @{
#     AllNodes = @(
#         @{
#             NodeName                    = 'localhost'
#             PSDscAllowPlainTextPassword = $True
#             PSDscAllowDomainUser = $True
#         }
#     )
# }
    
Configuration ComputerJoinDomain
{
    param
    (
	    [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [PSCredential]$AdminCreds,

        [Parameter(Mandatory)]
        [String]$ADDSdns
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration,xDSCDomainjoin, xNetworking, ComputerManagementDSC

    $DomainPrefix = $DomainName.Split('.')[0]
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$DomainPrefix\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface = Get-NetAdapter | Where-Object Name -Like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)


    $dscDomainAdmin = Get-AutomationPSCredential -Name 'dscDomainAdmin'
    $dscDomainName = Get-AutomationVariable -Name 'dscDomainName'
    $dnsServer = Get-AutomationVariable -Name 'dscDNSServer'


    Node $AllNodes.NodeName
    {
        
        
        # make sure the machine looks to the DC as DNS.
        #
        xDnsServerAddress DnsServerAddress
        {
            Address        = $ADDSdns
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

        # Domain Join
        xDSCDomainjoin JoinDomain
        {
            Domain = $DomainName
            Credential = $DomainCreds
            DependsOn  = "[xDnsServerAddress]DnsServerAddress"
        }
    }
}

#ComputerJoinDomain -ConfigurationData $ConfigData

#Login-AzAccount
#Set-AzContext -SubscriptionId ....
#Start-AzAutomationDscCompilationJob -ResourceGroupName 'dc-demo' -AutomationAccountName 'aa-demo' -ConfigurationName 'ComputerJoinDomain' -ConfigurationData $ConfigData