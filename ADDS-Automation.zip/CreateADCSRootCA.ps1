﻿configuration CreateADCSRootCA
{
    param
    (
	    [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$ADDSdns
    )

    Import-DscResource -ModuleName xAdcsDeployment, xDSCDomainjoin, xNetworking, ComputerManagementDSC
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface = Get-NetAdapter | Where-Object Name -Like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias = $($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

                #
        # make sure the machine looks to itself for DNS now.
        #
        xDnsServerAddress DnsServerAddress
        {
            Address        = $ADDSdns
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

        # Domain Join
        xDSCDomainjoin JoinDomain
        {
            DomainName = $DomainName
            Credential = $Admincreds
        }

        # Reboot after domain join
        PendingReboot RebootAfterDomainJoin
        {
            Name = "RebootAfterDomainJoin"
            DependsOn = "[xDSCDomainjoin]JoinDomain"
        }

        # Install ADCS Role
        WindowsFeature ADCSInstall
        {
            Ensure = "Present"
            Name = "ADCS-Cert-Authority"
            DependsOn = "[PendingReboot]RebootAfterDomainJoin"
        }

        # Install Management Tools
        WindowsFeature ADCSMgmt
        {
            Ensure = "Present"
            Name = "RSAT-ADCS"
            DependsOn = "[WindowsFeature]ADCSInstall"
        }

        # Configure Enterprise Root CA
        xADCSCertificationAuthority ADCSRootCA
        {
            Ensure = "Present"
            Credential = $adminCreds
            CAType = "EnterpriseRootCA"
            DependsOn = "[WindowsFeature]ADCSMgmt"
        }

        # Optional: Reboot after CA installation
        PendingReboot RebootAfterCAInstall
        {
            Name = "RebootAfterCAInstall"
            DependsOn = "[xADCSCertificationAuthority]ADCSRootCA"
        }
    }
}
