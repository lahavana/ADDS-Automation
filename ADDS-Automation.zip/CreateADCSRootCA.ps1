﻿configuration CreateADCSRootCA
{
    param
    (
	[Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
    )

    Import-DscResource -ModuleName xAdcsDeployment, xDSCDomainjoin, ComputerManagementDSC

[System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        # Domain Join
        xDSCDomainjoin JoinDomain
        {
            DomainName = $DomainName
            Credential = $Admincreds
        }

        # Reboot after domain join
        PendingReboot RebootAfterDomainJoin
        {
            Name = "RebootAfterDomainJoin"
            DependsOn = "[xDSCDomainjoin]JoinDomain"
        }

        # Install ADCS Role
        WindowsFeature ADCSInstall
        {
            Ensure = "Present"
            Name = "ADCS-Cert-Authority"
            DependsOn = "[PendingReboot]RebootAfterDomainJoin"
        }

        # Install Management Tools
        WindowsFeature ADCSMgmt
        {
            Ensure = "Present"
            Name = "RSAT-ADCS"
            DependsOn = "[WindowsFeature]ADCSInstall"
        }

        # Configure Enterprise Root CA
        xADCSCertificationAuthority ADCSRootCA
        {
            Ensure = "Present"
            Credential = $adminCreds
            CAType = "EnterpriseRootCA"
            DependsOn = "[WindowsFeature]ADCSMgmt"
        }

        # Optional: Reboot after CA installation
        PendingReboot RebootAfterCAInstall
        {
            Name = "RebootAfterCAInstall"
            DependsOn = "[xADCSCertificationAuthority]ADCSRootCA"
        }
    }
}
